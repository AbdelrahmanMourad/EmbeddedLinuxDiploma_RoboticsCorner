#ifndef DATE_H
#define DATE_H

#include <iostream>
#include <string>

class Date{
public:
    Date();
};

#endif
