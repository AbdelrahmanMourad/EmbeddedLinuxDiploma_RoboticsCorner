 #ifndef PERSON_H
 #define PERSON_H

 #include <vector>
 #include <string>
 #include "chatroom.h"
 
struct ChatRoom;

struct Person
 {
    std::string name;
    ChatRoom* room;
    std::vector<std::string> chat_log;

    Person(const std::string& name);

    void receive(const std::string& origin, const std::string& message);
    void say(const std::string& message) const;
    void pm(const std::string& who, const std::string& message) const;
    
 };
#endif