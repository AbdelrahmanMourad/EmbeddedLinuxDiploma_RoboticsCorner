#include "Date.h"

Date::Date()
{
    std::cout <<"20 of Sep \n";
}
