#include "Student.hpp"

int
main(int argc, char **argv)
{
  Student s("Joe");

  s.display();

  return 0;
}
